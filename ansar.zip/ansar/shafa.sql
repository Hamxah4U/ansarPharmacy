-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2025 at 01:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shafa`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers_tbl`
--

CREATE TABLE `customers_tbl` (
  `id` int(11) NOT NULL,
  `Fullname` varchar(100) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `address` varchar(200) NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers_tbl`
--

INSERT INTO `customers_tbl` (`id`, `Fullname`, `phone`, `email`, `password`, `address`, `created_by`, `created_at`) VALUES
(35, 'Hamza Ibrahim Danasabe', '08037856962', '', '', 'hh', 'hamxah4u@gmail.com', '2025-04-02 17:04:03'),
(36, 'Hamza Ibrahim Danasabe', '080378569629', 'hamxah4u@gmail.com', '', 'gg', 'hamxah4u@gmail.com', '2025-04-02 17:07:35'),
(37, 'Hamza Ibrahim Danasabe', '080378569627', '', '$2y$10$.CHKb7AZK2rgQratoVA1/eNuLEtq.JvylX2Bq9t6jfZJRTAhUPg16', 'hgh', 'hamxah4u@gmail.com', '2025-04-02 17:15:24'),
(38, 'Musa Sani', '080378569622', 'hamzaibrahim382@gmail.com', '$2y$10$CKTRRfpSmGj9KwNf70Tyi.rHZxKw4PU4PAso7Os2xzhje8NeAls9e', 'No10 Sheikh dahiru', 'hamxah4u@gmail.com', '2025-04-04 00:17:00');

-- --------------------------------------------------------

--
-- Table structure for table `department_tbl`
--

CREATE TABLE `department_tbl` (
  `deptID` int(11) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL DEFAULT 'Active',
  `registerby` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department_tbl`
--

INSERT INTO `department_tbl` (`deptID`, `Department`, `Status`, `registerby`) VALUES
(7, 'Store_Demo_001', 'Active', 'muhammadushafa@gmail.com'),
(31, 'Store_Demo_002', 'Active', 'hamxah4u@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `financecollect_tbl`
--

CREATE TABLE `financecollect_tbl` (
  `id` int(11) NOT NULL,
  `Collectorname` varchar(100) NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Reason` text NOT NULL,
  `Givername` varchar(100) NOT NULL,
  `Dateissued` datetime NOT NULL DEFAULT current_timestamp(),
  `Timegive` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `financecollect_tbl`
--

INSERT INTO `financecollect_tbl` (`id`, `Collectorname`, `Amount`, `Reason`, `Givername`, `Dateissued`, `Timegive`) VALUES
(19, 'musa', 88.00, 'nn', 'hamxah4u@gmail.com', '2025-04-02 17:23:50', '2025-04-02 17:23:50'),
(20, 'Maryam', 888.00, 'kkk', 'hamxah4u@gmail.com', '2025-04-02 17:25:15', '2025-04-02 17:25:15');

-- --------------------------------------------------------

--
-- Table structure for table `product_tbl`
--

CREATE TABLE `product_tbl` (
  `proID` int(11) NOT NULL,
  `Department` int(11) NOT NULL,
  `Productname` varchar(50) NOT NULL,
  `Price` varchar(200) NOT NULL,
  `Status` varchar(20) NOT NULL DEFAULT 'Active',
  `DateRegister` date NOT NULL,
  `TimeRegister` time NOT NULL,
  `RegisterBy` varchar(50) NOT NULL,
  `UpdateBy` varchar(100) DEFAULT NULL,
  `DateUpdate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supply_tbl`
--

CREATE TABLE `supply_tbl` (
  `SupplyID` int(11) NOT NULL,
  `Department` int(11) NOT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Pprice` decimal(10,2) NOT NULL,
  `UnitPack` varchar(20) NOT NULL,
  `ExpiryDate` date NOT NULL,
  `SupplyDate` datetime NOT NULL DEFAULT current_timestamp(),
  `RecordedBy` varchar(255) DEFAULT NULL,
  `Status` varchar(20) NOT NULL DEFAULT 'Active',
  `StockQuantity` int(11) GENERATED ALWAYS AS (`Quantity` * `UnitPack`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supply_tbl`
--

INSERT INTO `supply_tbl` (`SupplyID`, `Department`, `ProductName`, `Quantity`, `Price`, `Pprice`, `UnitPack`, `ExpiryDate`, `SupplyDate`, `RecordedBy`, `Status`) VALUES
(89, 7, 'product_1', 138, 2500.00, 2000.00, '', '2025-02-23', '2025-03-28 14:44:02', 'hamxah4u@gmail.com', 'Active'),
(90, 7, 'product_2', 470, 6500.00, 5000.00, '', '2025-03-01', '2025-03-28 14:44:41', 'hamxah4u@gmail.com', 'Active'),
(91, 31, 'Demo_one', 280, 1000.00, 750.00, '', '2025-03-21', '2025-03-28 14:48:39', 'hamxah4u@gmail.com', 'Active'),
(92, 7, 'Beans', 222, 33.00, 22.00, '', '2027-01-01', '2025-04-02 19:59:02', 'hamxah4u@gmail.com', 'Active'),
(93, 7, 'ANC', 0, 90.00, 77.00, '', '2025-03-31', '2025-04-02 19:59:52', 'hamxah4u@gmail.com', 'Active'),
(94, 31, 'Inj', 333, 33.00, 22.00, '', '2025-06-02', '2025-04-02 20:01:09', 'hamxah4u@gmail.com', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_tbl`
--

CREATE TABLE `transaction_tbl` (
  `TID` int(11) NOT NULL,
  `tCode` varchar(50) NOT NULL,
  `tDepartment` int(11) DEFAULT NULL,
  `Product` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `qty` float DEFAULT NULL,
  `Amount` float NOT NULL,
  `Credit` float DEFAULT NULL,
  `Customer` varchar(100) NOT NULL,
  `TransacDate` date DEFAULT NULL,
  `TransacTime` time NOT NULL,
  `TrasacBy` varchar(100) NOT NULL,
  `Status` varchar(20) DEFAULT 'Not-Paid',
  `nhisno` varchar(20) DEFAULT NULL,
  `cash` varchar(200) DEFAULT NULL,
  `transfer` varchar(200) DEFAULT NULL,
  `pos` varchar(200) DEFAULT NULL,
  `crypto` varchar(200) DEFAULT NULL,
  `CID` int(11) DEFAULT NULL,
  `narration` varchar(200) DEFAULT NULL,
  `creditstatus` varchar(20) DEFAULT NULL,
  `pprice` float DEFAULT NULL,
  `pprice_amount` float GENERATED ALWAYS AS (`pprice` * `qty`) STORED,
  `profit` float GENERATED ALWAYS AS (coalesce(`Amount`,0) + coalesce(`Credit`,0) - coalesce(`pprice_amount`,0)) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_tbl`
--

INSERT INTO `transaction_tbl` (`TID`, `tCode`, `tDepartment`, `Product`, `Price`, `qty`, `Amount`, `Credit`, `Customer`, `TransacDate`, `TransacTime`, `TrasacBy`, `Status`, `nhisno`, `cash`, `transfer`, `pos`, `crypto`, `CID`, `narration`, `creditstatus`, `pprice`) VALUES
(1544, '250403590419005', 7, 89, 2500, 2, 0, 5000, 'Hamza Ibrahim Danasabe', '2025-04-03', '17:06:40', 'hamxah4u@gmail.com', 'Not-Paid', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1546, '250403590419005', 7, 90, 6500, 3, 0, 19500, 'Hamza Ibrahim Danasabe', '2025-04-03', '17:10:20', 'hamxah4u@gmail.com', 'Not-Paid', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 5000),
(1547, '250403455616688', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-03', '20:38:02', 'hamxah4u@gmail.com', 'Not-Paid', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1548, '250403795767112', 7, 89, 2500, 2, 0, 5000, 'Hamza Ibrahim Danasabe', '2025-04-03', '20:40:22', 'hamxah4u@gmail.com', 'Not-Paid', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1550, '250403770790855', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-03', '20:44:33', 'hamxah4u@gmail.com', 'Not-Paid', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1551, '250403253101244', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-03', '20:46:16', 'hamxah4u@gmail.com', 'Credit', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1552, '250403352160441', 7, 89, 2500, 3, 0, 7500, 'Hamza Ibrahim Danasabe', '2025-04-03', '20:49:29', 'hamxah4u@gmail.com', 'Credit', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1553, '250403124551788', 7, 89, 2500, 2, 0, 5000, 'Hamza Ibrahim Danasabe', '2025-04-03', '20:51:23', 'hamxah4u@gmail.com', 'Not-Paid', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1554, '250403128279098', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-03', '20:53:18', 'hamxah4u@gmail.com', 'Not-Paid', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1555, '250403289221377', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-03', '21:11:02', 'hamxah4u@gmail.com', 'Not-Paid', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1556, '250403317932738', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-03', '21:11:54', 'hamxah4u@gmail.com', 'Credit', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1557, '250403491267530', 7, 89, 2500, 2, 0, 5000, 'Hamza Ibrahim Danasabe', '2025-04-03', '21:12:19', 'hamxah4u@gmail.com', 'Credit', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1558, '250404860004370', 7, 89, 2500, 2, 0, 5000, 'Hamza Ibrahim Danasabe', '2025-04-03', '23:25:13', 'hamxah4u@gmail.com', 'Credit', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1559, '250404716593559', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-03', '23:26:28', 'hamxah4u@gmail.com', 'Credit', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1560, '250404758880383', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-03', '23:41:18', 'hamxah4u@gmail.com', 'Credit', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1561, '250404359320611', 7, 89, 2500, 4, 0, 10000, 'Hamza Ibrahim Danasabe', '2025-04-03', '23:43:24', 'hamxah4u@gmail.com', 'Credit', '8037856962', NULL, NULL, NULL, NULL, 35, NULL, NULL, 2000),
(1562, '250404397314036', 31, 91, 1000, 2, 0, 2000, 'Hamza Ibrahim Danasabe', '2025-04-04', '00:07:33', 'hamxah4u@gmail.com', 'Not-Paid', '80378569629', NULL, NULL, NULL, NULL, 36, NULL, NULL, 750),
(1565, '250404925965476', 7, 89, 2500, 1, 0, 2500, 'Hamza Ibrahim Danasabe', '2025-04-04', '00:13:27', 'hamxah4u@gmail.com', 'Credit', '80378569629', NULL, NULL, NULL, NULL, 36, NULL, NULL, 2000),
(1566, '250404204230567', 31, 91, 1000, 1, 0, 1000, 'Hamza Ibrahim Danasabe', '2025-04-04', '00:15:43', 'hamxah4u@gmail.com', 'Credit', '80378569629', NULL, NULL, NULL, NULL, 36, NULL, NULL, 750),
(1567, '250404885438887', 7, 89, 2500, 2, 0, 5000, 'Musa Sani', '2025-04-04', '00:17:16', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1568, '250404885438887', 7, 90, 6500, 4, 0, 26000, 'Musa Sani', '2025-04-04', '00:17:32', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 5000),
(1569, '250404885438887', 31, 91, 1000, 5, 0, 5000, 'Musa Sani', '2025-04-04', '00:17:45', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 750),
(1570, '250404160641923', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-04', '00:22:40', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1571, '250404763239315', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-04', '11:13:45', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1572, '250405907516123', 7, 93, 90, 6, 540, NULL, 'Musa Abdullahi', '2025-04-05', '17:40:06', 'hamxah4u@gmail.com', 'Paid', '0', '540', '', '', NULL, NULL, NULL, NULL, 77),
(1573, '250406445829164', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-05', '23:56:02', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1574, '250406836720711', 7, 89, 2500, 2, 0, 5000, 'Musa Sani', '2025-04-06', '00:03:11', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1575, '250406836720711', 7, 90, 6500, 3, 0, 19500, 'Musa Sani', '2025-04-06', '00:03:22', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 5000),
(1576, '250406836720711', 31, 91, 1000, 1, 0, 1000, 'Musa Sani', '2025-04-06', '00:03:34', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 750),
(1577, '250406541961494', 7, 89, 2500, 2, 0, 5000, 'Musa Sani', '2025-04-06', '00:14:47', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1578, '250406541961494', 7, 90, 6500, 4, 0, 26000, 'Musa Sani', '2025-04-06', '00:15:15', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 5000),
(1579, '250406541961494', 31, 91, 1000, 1, 0, 1000, 'Musa Sani', '2025-04-06', '00:15:29', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 750),
(1580, '250406135939243', 31, 91, 1000, 1, 0, 1000, 'Musa Sani', '2025-04-06', '00:18:23', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 750),
(1581, '250406135939243', 7, 89, 2500, 2, 0, 5000, 'Musa Sani', '2025-04-06', '00:18:32', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1582, '250406135939243', 7, 90, 6500, 2, 0, 13000, 'Musa Sani', '2025-04-06', '00:18:45', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 5000),
(1583, '250406366357678', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-06', '00:21:12', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1584, '250406366357678', 7, 90, 6500, 3, 0, 19500, 'Musa Sani', '2025-04-06', '00:21:30', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 5000),
(1585, '250406382737559', 7, 89, 2500, 4, 0, 10000, 'Musa Sani', '2025-04-06', '00:24:17', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1586, '250406239351251', 7, 89, 2500, 3, 0, 7500, 'Musa Sani', '2025-04-06', '00:27:02', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1587, '250406239351251', 7, 90, 6500, 6, 0, 39000, 'Musa Sani', '2025-04-06', '00:27:11', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 5000),
(1588, '250406752899992', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-06', '00:34:56', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1589, '250406855725372', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-06', '00:42:08', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1590, '250406979001909', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-06', '00:44:39', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1591, '250406939690845', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-06', '00:57:50', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1592, '250406559130008', 31, 91, 1000, 2, 0, 2000, 'Musa Sani', '2025-04-06', '01:00:01', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 750),
(1593, '250406339230274', 7, 89, 2500, 1, 0, 2500, 'Musa Sani', '2025-04-06', '09:56:58', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1594, '250406784513781', 7, 89, 2500, 2, 0, 5000, 'Musa Sani', '2025-04-06', '09:59:43', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000),
(1595, '250406361548445', 7, 89, 2500, 4, 0, 10000, 'Musa Sani', '2025-04-06', '10:22:04', 'hamxah4u@gmail.com', 'Credit', '80378569622', NULL, NULL, NULL, NULL, 38, NULL, NULL, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `users_tbl`
--

CREATE TABLE `users_tbl` (
  `userID` int(11) NOT NULL,
  `Fullname` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `UserPassword` varchar(255) NOT NULL,
  `Department` int(11) NOT NULL,
  `DateRegister` date NOT NULL,
  `TimeRegister` time NOT NULL,
  `Role` varchar(10) NOT NULL,
  `Status` varchar(20) NOT NULL DEFAULT 'Active',
  `Phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_tbl`
--

INSERT INTO `users_tbl` (`userID`, `Fullname`, `Email`, `UserPassword`, `Department`, `DateRegister`, `TimeRegister`, `Role`, `Status`, `Phone`) VALUES
(11, 'Hamza Ibrahim Danasabe', 'hamxah4u@gmail.com', '$2y$10$rsAPBqxnifDbGLBhelhxwekKyJqdCP1uMTuYivZDjKVXKnpUyzYwm', 7, '0000-00-00', '00:00:00', 'Admin', 'Active', '08037856962'),
(33, '‎Muhammad Shafa‎', 'muhammadushafa@gmail.com', '$2y$10$DkHQCo5IuEXSjp5Y26CNPu/iIOPYmoSwSUH.jta4g.DbiSc07okCi', 7, '0000-00-00', '00:00:00', 'Admin', 'Active', '08032987462'),
(35, 'Muhammad Nafiu', 'nafiumohammedomar@gmail.com', '$2y$10$tAt20LIGyh.gvk1Zthwu1uIqR9IM9wLcW6m4bj.7x7Vv/mPqu2y5W', 7, '0000-00-00', '00:00:00', 'User', 'Active', '07066646961'),
(36, 'Rukayya Hassan Yalwa', 'hamxah4u@gmail.co', '$2y$10$//xBp/gUbRKudSguMJ42XuoD088ETIoBLFfv4Xe.d4yLn2DlEqWsG', 7, '0000-00-00', '00:00:00', 'User', 'Active', '07048734630');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers_tbl`
--
ALTER TABLE `customers_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department_tbl`
--
ALTER TABLE `department_tbl`
  ADD PRIMARY KEY (`deptID`);

--
-- Indexes for table `financecollect_tbl`
--
ALTER TABLE `financecollect_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_tbl`
--
ALTER TABLE `product_tbl`
  ADD PRIMARY KEY (`proID`),
  ADD KEY `Department` (`Department`);

--
-- Indexes for table `supply_tbl`
--
ALTER TABLE `supply_tbl`
  ADD PRIMARY KEY (`SupplyID`),
  ADD UNIQUE KEY `ProductName` (`ProductName`,`ExpiryDate`),
  ADD KEY `Department` (`Department`);

--
-- Indexes for table `transaction_tbl`
--
ALTER TABLE `transaction_tbl`
  ADD PRIMARY KEY (`TID`),
  ADD KEY `Product` (`Product`),
  ADD KEY `transaction_tbl_ibfk_1` (`tDepartment`);

--
-- Indexes for table `users_tbl`
--
ALTER TABLE `users_tbl`
  ADD PRIMARY KEY (`userID`),
  ADD KEY `Department` (`Department`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers_tbl`
--
ALTER TABLE `customers_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `department_tbl`
--
ALTER TABLE `department_tbl`
  MODIFY `deptID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `financecollect_tbl`
--
ALTER TABLE `financecollect_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `product_tbl`
--
ALTER TABLE `product_tbl`
  MODIFY `proID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `supply_tbl`
--
ALTER TABLE `supply_tbl`
  MODIFY `SupplyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `transaction_tbl`
--
ALTER TABLE `transaction_tbl`
  MODIFY `TID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1596;

--
-- AUTO_INCREMENT for table `users_tbl`
--
ALTER TABLE `users_tbl`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product_tbl`
--
ALTER TABLE `product_tbl`
  ADD CONSTRAINT `product_tbl_ibfk_1` FOREIGN KEY (`Department`) REFERENCES `department_tbl` (`deptID`);

--
-- Constraints for table `supply_tbl`
--
ALTER TABLE `supply_tbl`
  ADD CONSTRAINT `supply_tbl_ibfk_1` FOREIGN KEY (`Department`) REFERENCES `department_tbl` (`deptID`);

--
-- Constraints for table `transaction_tbl`
--
ALTER TABLE `transaction_tbl`
  ADD CONSTRAINT `transaction_tbl_ibfk_1` FOREIGN KEY (`tDepartment`) REFERENCES `department_tbl` (`deptID`),
  ADD CONSTRAINT `transaction_tbl_ibfk_2` FOREIGN KEY (`Product`) REFERENCES `supply_tbl` (`SupplyID`);

--
-- Constraints for table `users_tbl`
--
ALTER TABLE `users_tbl`
  ADD CONSTRAINT `users_tbl_ibfk_1` FOREIGN KEY (`Department`) REFERENCES `department_tbl` (`deptID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
