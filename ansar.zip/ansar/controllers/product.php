<?php
    require 'views/product.view.php';
?>