<?php
  require 'views/updateprofile.view.php'
?>