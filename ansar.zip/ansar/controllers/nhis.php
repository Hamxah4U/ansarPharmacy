<?php
    require 'views/nhis.view.php';
?>