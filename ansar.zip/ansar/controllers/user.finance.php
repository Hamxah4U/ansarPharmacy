<?php
    require 'views/finance.view.php';
?>