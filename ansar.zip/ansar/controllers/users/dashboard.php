<?php
  require 'views/user/dashboard.view.php';