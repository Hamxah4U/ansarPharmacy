<?php
  require 'views/viewcreditors.view.php';
?>